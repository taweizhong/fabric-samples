#!/bin/bash

export PATH=${PWD}/../bin:$PATH
export FABRIC_CFG_PATH=$PWD/../config/
# 打包链码
peer lifecycle chaincode package test.tar.gz --path ../test-network/sacc --lang golang --label sacc1


